<?php
$str = "I love you";
echo $str[0];
?>
