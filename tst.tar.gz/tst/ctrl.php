<?php
$a = "1".""."2";

$str =  sprintf("%c", 0x001);  
print $str;

?>
