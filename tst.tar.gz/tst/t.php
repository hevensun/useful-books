<?php
$arr = array("key"=>"value");
print_r($arr);

function changeStyle(& $str) {
    $arrStr=explode("_", $str);
    foreach($arrStr as $key=>$value){
        echo $key." ".$value."\n";
        $arrStr[$key]=strtoupper(substr($value,0,1)).substr($value,1);
    }
    return implode("",$arrStr);
}
$s = "open_door";
echo changeStyle ( $s );

print "1"===1;
echo  "\n";
print "1"==1; 
echo "\n";

print strlen("abc我爱你");
echo "\n";
print mb_strlen("abc我爱你", "utf8");
echo "\n";

$str = 'sorry, I love you.';
$str = preg_replace('/[aeiou]/', '', $str);
print $str."\n";

$array = array(1, 2, 3);
echo implode(',', $array), "\n";

foreach ($array as &$value) {}    // by reference
print_r($array);
echo implode(',', $array), "\n";

foreach ($array as $value) {}     // by value (i.e., copy)
print_r($array);
echo implode(',', $array), "\n";
