#!/usr/bin/python
# -*- coding: utf-8 -*- 
import sys
import os
import xlrd
import re
from  datetime  import  *
from mysqlDB import mysqlDB


def open_excel(file):
    try:
        data = xlrd.open_workbook(file)
        return data
    except Exception,e:
        print str(e)

def read_excel_table(file, title_map={}, colname_index=0, by_index=0):
    data  = open_excel(file)
    table = data.sheets()[by_index]
    nrows = table.nrows 
    ncols = table.ncols 

    # get colname for excel
    colnames =  table.row_values(colname_index) 
    list     =  []
    
    systime     = datetime.now()
    notice_file = os.path.basename(file)
    [tag, province, notice_time] = notice_file.split("_")
    if len(tag)==0 or len(province)==0 or len(notice_time) == 0:
        print "file name error[%s]" % (file)
        return []

    for rownum in range(1,nrows):

        row = table.row_values(rownum)
        if row:
            app = [""] * len(title_map)
            for i in range(len(colnames)):
                if len(title_map) == 0:
                    app[i] = row[i].encode("utf-8") 
                else:
                    app[title_map.keys().index(colnames[i])] = row[i].encode("utf-8")

            app[title_map.keys().index("insert_time")] = systime
            app[title_map.keys().index("notice_time")] = notice_time.split(".")[0]
            app[title_map.keys().index("province")]    = province
            print app
            list.append(app)
    return list

def insert_into_db(mydb, table_name, sections, tableList):
    """insert data to db's table"""
    print (sections)
    sql = "insert into %s(%s) values(%s)" % (table_name,\
            ",".join(sections), ",".join(["%s"]*len(sections)))

    print sql
    mydb.executeMany(sql, tableList)


def main(dirList, pattern, mydb, table_name, title_dict):
    """process data"""
    # get last insert time
    sqlCmd = "select unix_timestamp(max(insert_time)),max(insert_time) from notice;"
    items = mydb.executeSQL(sqlCmd);
    if len(items)>0 and len(items[0])>0:
        last_time     = int(items[0][0])
        last_time_str = items[0][1]
    else:
        last_time = 0
    print "get last insert time : %d [%s] " %(last_time, last_time_str)

    # get file list after last insert time
    fileList = []
    for dir in dirList:
        files = os.listdir(dir)
        for fileName in files:            
            if re.search(pattern, fileName) != None:
                pathName = dir + '/' + fileName
                if (int(os.path.getmtime(pathName))) > last_time:
                    fileList.append(pathName)
                else:
                    print "%s alread processed" %(pathName)

    print fileList

    for file in fileList:
        # process each file
        #tableList = read_excel_table("gonggao_zhejiang_201408201230.xls", title_dict)
        tableList = read_excel_table(file, title_dict)
        print title_dict.values()
        print tableList

        if len(tableList)>0:
            insert_into_db(mydb, table_name, title_dict.values(), tableList)
        else:
            print "can't read any data from excel[%s]" % (file)


if __name__=="__main__":

    title_dict = {u"标题":"title", u"内容":"content", "insert_time":"insert_time",\
            "province":"province", "notice_time":"notice_time"}

    # insert notice table name
    table_name = "notice"

    # db info for mysql
    db_info    = {"server":"192.168.39.174",
            "user"     : "root",
            "passwd"   : "123456",
            "database" : "test",
            "charset"  : "utf8"
            }

    # match the excel file name pattern
    pattern = "^gonggao_[\w]*_[0-9]*.xls";

    try:
        mydb = mysqlDB(db_info)
        mydb.connect()
        main(sys.argv[1:], pattern, mydb, table_name, title_dict)
    except Exception,e:
        print str(e)

    mydb.close()
