#!/usr/bin/python
#-*- coding: utf-8 -*-
"""
mysql db interface
"""
#
#

import threading
import MySQLdb

class mysqlDB:
    """generic database"""
    def __init__(self, dbInfo):
        # dbInfo:{'server':'10.1.123.456', \
        #         'user':'root', \
        #         'passwd':"", \
        #         'database':"usDB", \
        #         'port':3306}
        self.lock = threading.Lock()
        self.dbInfo = dbInfo
        self.db = None
    
    def connect(self):
        "connect to database"
        server = self.dbInfo['server']
        user = self.dbInfo['user']
        passwd = self.dbInfo['passwd']
        database = self.dbInfo['database']
        
        if self.dbInfo.has_key('port'):
            port = self.dbInfo['port']
        else:
            port = 3306
        
        try:            
            self.conn = MySQLdb.connect(server, user, passwd, database, port)
            self.db = self.conn.cursor()
            return 'OK'
        except:
            return 'ERROR'

    def connectBySection(self, configFile, sectionName):
        import cfgLoad
        dbInfo = cfgLoad.mysqlCfgGet(configFile, sectionName)    
        if dbInfo == None:
            return "ERROR"
        self.dbInfo = dbInfo
        return self.connect()

    def close(self):
        "close the connection with database"   
        try:     
            self.db.close()
            self.conn.commit()
            self.conn.close()
            return "OK"
        except:
            return "ERROR"                        

    def TBExist(self, TBName):
        "whether given table name exist"
        sqlCmd = "SHOW TABLES LIKE '" + TBName + "'"
        self.db.execute(sqlCmd)
        items = self.db.fetchall()
        
        return (len(items) != 0)

    def TBDrop(self, TBName):
        "drop table"
        sqlCmd = "DROP TABLE IF EXISTS " + TBName
        self.db.execute(sqlCmd)

    def executeSQL(self, sqlCmd):
        """run a sql command"""
        self.db.execute(sqlCmd)
        items = self.db.fetchall()
        return items

    def executeMany(self, sqlCmd, dataLines, step=10):
        "execute multiple cmd at one time"
        # 考虑：
        # (1) 性能的提高：比多次单条执行要快的多
        # (2) 如果一次命令太多，可能超过max msg size，所以需要封装
        #  
        # STEP_LENGTH设为10似乎就可以了: 比设为1性能要好，而对数据项
        #      大的情况，又不会超过max msg size
        STEP_LENGTH = step        
        
        stepNum = len(dataLines) / STEP_LENGTH
        if (len(dataLines) % STEP_LENGTH) != 0:
            stepNum = stepNum + 1
            
        for step in range(0, stepNum):
            subLines = dataLines[STEP_LENGTH * step: STEP_LENGTH * (step + 1)]
            # use executemany(), instead of execute()
            self.db.executemany(sqlCmd, subLines)
        
    def escapeString(self,str):
        """ escape string """
        returnStr = None
        try :
            returnStr = MySQLdb.escape_string(str)
        except:
            return returnStr
        return returnStr
