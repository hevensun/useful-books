#!/bin/bash
WORKDIR=`cd $(dirname $0);pwd`
cd $WORKDIR

# set PYTHONPATH
export PYTHONPATH=$PYTHONPATH:$WORKDIR/lib

dataDir=$WORKDIR/data

# create table if necessary
bash $WORKDIR/create_table.sh

# do the job
python $WORKDIR/get_notice.py $dataDir
