#!/bin/bash

echo "create table if not exists notice(
id       int(11) NOT NULL AUTO_INCREMENT,
province varchar(255) NOT NULL,
title    varchar(255) DEFAULT '',
content  text DEFAULT '',
notice_time varchar(20) DEFAULT NULL,
insert_time datetime DEFAULT NULL,
PRIMARY KEY (id),
INDEX(province,insert_time),
INDEX (insert_time)

) ENGINE=MyISAM DEFAULT CHARSET=utf8;

"|mysql -uroot -p123456 test
