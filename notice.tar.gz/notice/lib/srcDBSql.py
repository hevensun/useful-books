#!/usr/bin/python
#-*- coding: gbk -*-
"""
Get data from source database - a framework
"""
#
import log
import mysqlDBIf
import cfgLoad

class dbParser:
    def __init__(self, dbType, confFileName, key): 
        self.dbType = dbType
        self.confFileName = confFileName
        
        self.key = key
        self.db = None
    
    def dbOpen(self):
        "open the database"
        dbInfo = cfgLoad.mysqlCfgGet(self.confFileName, self.key)
        if dbInfo == None :
            log.msg('SRC_DB_SQL', 'ERROR', \
                   'reed config file failed')
            return "ERROR"
        #  dbType: 'mysql', 'oracle'
        #
        # Initialize db, according to dbType
        if self.dbType == 'mysql' :
            self.db = mysqlDBIf.genericDB(dbInfo)
        # elif dbType == 'oracle':
        #     self.db = oraDBIf.genericDB(dbInfo)
        else:
            log.msg('SRC_DB_SQL', 'ERROR', \
                    'unknown db type(%s)' % self.dbType)   
            return   "ERROR"  
        
        if self.db.connect() != 'OK':
            log.msg('SRC_DB_SQL', 'ERROR', 'dbOpen():connect to db')
            return 'ERROR'
            
        return 'OK'

    def dbClose(self):
        "open the database"
        if self.db.close() != 'OK':
            log.msg('SRC_DB_SQL', 'ERROR', 'dbClose()')
            return 'ERROR'
            
        return 'OK'    

    def dataFetch(self, sql):
        "fetch data from table"
        # RETURNs:
        #       None, 
        #       [],
        #       [data0, data1, ...]        
        # whether table exist

        # fetch from db table
        try :
            self.db.db.execute(sql)
            data = self.db.db.fetchall()
        except Exception, e :
            data = None
            log.msg('SRC_DB_SQL', 'ERROR', 'dataFetch(): sql_%s : %s' \
                    % (sql, str(e)))
            
        return data
