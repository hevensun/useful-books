#!/usr/bin/python
"""
cfgLoad - load config.conf
"""
#
import sys
import log
import ConfigParser
import string

CONF_PATH_LINUX = '/home/webdev/conf/'
CONF_PATH_WIN = 'd:\\project\\web_stock_rep\\stock_proj\\trunk\\common\\conf\\test\\'

def _blankRemove(strLine):
    "remove blank at end of line"    
    retVal = ""
    
    for ch in strLine:
        if ord(ch) in range(33, 127):
            retVal = retVal + ch
        
    return retVal

def _isParaStart(strLine):
    "it is start of paragraph?"
    if strLine.startswith('[') and strLine.endswith(']'):
        return True

    return False
    
def _paraTitleGet(strLine):
    "get title of paragraph"
    title = strLine[1:len(strLine) - 1]
    return title

def _isValueAssign(strLine):
    "it is an assign?"
    items = strLine.split('=')
    if len(items) == 2:
        return True
        
    return False
    
def _valueAssignGet(strLine):
    "get value in valueAssign"
    return strLine.split('=')

def _cfgParse(file):
    "parse cfg file"
    # create ConfigParser
    cp = ConfigParser.ConfigParser()
    
    # set this option, to make case-sensitive
    cp.optionxform = str
    
    # parse the file
    cp.readfp(file)
    
    config = {}
    for paraTitle in cp.sections():
        # parse each config section
        paraValue = {}
        for opt in cp.options(paraTitle):
            # parse each option in one section
            paraValue[opt] = string.strip(cp.get(paraTitle, opt))
        
        config[paraTitle] = paraValue        
                
    return config
    
def _cfgLoad(fileName, cfgDir=None):
    "load config from file"
    # compose full-path file name
    if cfgDir == None:
        # get filename depend on platform
        if sys.platform == 'win32':
            path = CONF_PATH_WIN        
        else:
            path = CONF_PATH_LINUX
    else:
        if not cfgDir.endswith('/'):
            cfgDir = cfgDir + '/'
        path = cfgDir
    
    fileName = path + fileName
    
    # open the file
    try:
        f = open(fileName)
    except:
        log.msg('LIB_CFG_LOAD', 'ERROR', \
                '_cfgLoad():in open(%s)' % fileName)
        return None
    
    # parse the file
    retVal = _cfgParse(f)
    
    # close the file
    f.close()

    return retVal

def _cfgGet(cfgTable, title):
    "get config from cfgTable, with given title"
    if cfgTable.has_key(title):
        retVal = cfgTable[title]
    else:
        retVal = None
        log.msg('LIB_CFG_LOAD', 'ERROR', \
                '_cfgGet():in find %s from config' % title)

    return retVal

def cfgGet(cfgFile, title, cfgDir=None):
    "get cfg of given title from given cfgFile"
    # get cfgTable from cfgFile
    cfgTable = _cfgLoad(cfgFile, cfgDir)
    
    if cfgTable == None:
        log.msg('LIB_CFG_LOAD', 'ERROR', \
                'cfgGet():in _cfgLoad(%s)' % cfgFile)
        return None

    # get title from cfgTable
    return _cfgGet(cfgTable, title)             

def mysqlCfgGet(cfgFile, title, cfgDir=None):
    "get mysql config"
    cfg = cfgGet(cfgFile, title, cfgDir)
    
    if cfg == None:
        log.msg('LIB_CFG_LOAD', 'ERROR', \
                'mysqlCfgGet():in cfgGet(%s, %s)' % (cfgFile, title))
        return None

    if not(cfg.has_key('host') and cfg.has_key('port') and cfg.has_key('user')\
            and cfg.has_key('pwd') and cfg.has_key('dbname')):
        log.msg('LIB_CFG_LOAD', 'ERROR', \
                'mysqlCfgGet():in find all reqs from %s' % title) 
        return None

    dbInfo = {}
    dbInfo['server'] = cfg['host']
    dbInfo['user'] = cfg['user']
    dbInfo['passwd'] = cfg['pwd']
    dbInfo['database'] = cfg['dbname']
    
    try:
        dbInfo['port'] = int(cfg['port'])
    except:
        log.msg('LIB_CFG_LOAD', 'ERROR', \
                'mysqlCfgGet():in int(port), %s' % cfg['port'])        
        dbInfo['port'] = 3306

    return dbInfo




