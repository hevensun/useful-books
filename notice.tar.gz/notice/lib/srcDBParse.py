#!/usr/bin/python
#-*- coding: utf-8 -*-
"""
Get data from source database - a framework
"""
#
#
#
import log
import mysqlDBIf


#   Format of dbDict:
#       {'tableName': tableName,
#        'columns': columnList}
#
#   Format of columnList:
#       [colItem_0, colItem_1, ..., colItem_N}
#       * ����ֻ��Ҫ�г���Ҫ������������
#       * ���ĳ�е��к���dbDcit��û�г��֣���������ݽ��������ڽ����
#   
#   Format of colItem_N:
#       [name_N, func_N]
#       * name_N: column name in source db
#       * func_N: function to convert given column to final format
#

def _sqlFetchCmdGen(dbDict, whereStr):
    "generate sql cmd for tableFetch"
    # compose sql with given dbDict
    colNames = []
    for colItem in dbDict['columns']:
        colNames.append(colItem[0])
    
    sqlCmd = "SELECT " + ",".join(colNames) + " FROM " + dbDict['tableName']
    
    # add whereStr
    if whereStr != None:
        sqlCmd = sqlCmd + " " + whereStr
    
    return sqlCmd
    
class dbParser:
    def __init__(self, dbType, dbInfo):
        #  dbType: 'mysql', 'oracle'
        #
        # Initialize db, according to dbType
        if dbType == 'mysql':
            self.db = mysqlDBIf.genericDB(dbInfo)
        elif dbType == 'oracle':
            import oraDBIf
            self.db = oraDBIf.genericDB(dbInfo)
        else:
            log.msg('SRC_DB_PARSE', 'ERROR', \
                    'unknown db type(%s)' % dbType)                            

        self._isValidRow = None
                        
        self.dataLines = []             # list of data lines
    
    def dbOpen(self):
        "open the database"
        if self.db.connect() != 'OK':
            log.msg('SRC_DB_PARSE', 'ERROR', 'dbOpen():connect to db')
            return 'ERROR'
            
        return 'OK'

    def dbClose(self):
        "open the database"
        if self.db.close() != 'OK':
            log.msg('SRC_DB_PARSE', 'ERROR', 'dbClose()')
            return 'ERROR'
            
        return 'OK'    

    def isValidRow(self, rowData):
        "whether this line is valid"
        # RETURNs: True, or False"
        if self._isValidRow == None:
            return True
        else:
            return self._isValidRow(rowData)

    def _rowDataProc(self, rowDataRaw, dbDict):
        "convert from raw row data to final format"
        ret = []
        for colNum in range(0, len(dbDict['columns'])):
            # convert the data, with given function
            data = dbDict['columns'][colNum][1](rowDataRaw[colNum])            
            ret.append(data)
        
        return ret

    def tableFetch(self, dbDict, isValidRow=None, whereStr=None):
        "fetch data from table"
        #   Params:
        #       dbDict      - columns to read from DB
        #       isValidRow  - callback function for check one row of data
        #       whereStr    - "where ..." in sql, e.g., "where SC='us'"
        # 
        #   RETURNs:
        #       None, 
        #       [],
        #       [data0, data1, ...]
        #
        self._isValidRow = isValidRow
        
        # whether table exist
        if not self.db.TBExist(dbDict['tableName']):
            return None

        # fetch from db table
        sqlCmd = _sqlFetchCmdGen(dbDict, whereStr)
        self.db.db.execute(sqlCmd)
        data = self.db.db.fetchall()

        # process each line of data
        self.dataLines = []
        for rowDataRaw in data:
            # decide whether this line is the data
            if self.isValidRow(rowDataRaw):
                rowData = self._rowDataProc(rowDataRaw, dbDict)
                
                if rowData != None:
                    self.dataLines.append(rowData)
        
        return self.dataLines
