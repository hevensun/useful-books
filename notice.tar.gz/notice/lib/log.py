#!/usr/bin/python
"""
log module in python

Description:
    This module is used to write log message to the file
    or the std console.
"""
#
#

import threading
import time
import sys

# sw: [stdOut, all, event, warn, error]
_logSwitch = {'stdOut'  : 1,    # use console output
              'all'     : 1,    # switch for all logs
              'event'   : 1,    # switch for event logs
              'warn'    : 1,    # switch for warn logs
              'error'   : 1     # switch for warn logs
            }

# switches tables
_logSwtTbl = \
{\
    "LOG"         : [1, 1, 1],\
    # add new module switches here
    # NOTICE: only switch of libary module can be added here \
    # format: Module_Name : [Error_Switch, Warning_Switch, Event_Switch] \
    "SSOCK"         : [1, 1, 1],      # sSock.py      \
    "COMMON_MSG"    : [1, 1, 1],      # commonMsg.py    \
    "SERV_IF"       : [1, 1, 1],      # servIf.py       \
    "BASIC_SERV"    : [1, 1, 1],      # basicServer.py      \   
    "IM_DATAIF"     : [1, 1, 1],      # imDataIf.py      \  
    "UDP_MSG_SERV"  : [1, 1, 1],      # udpMsgServ.py      \  
    "TCP_MSG_SERV"  : [1, 1, 1],      # tcpMsgServ.py      \     

    # for parsing xls and csv file
    "XLS_TO_DB"         : [1, 1, 1],  # xlsToDB.py  \
    "XLS_FILE_PARSE"    : [1, 1, 1],  # xlsFileParse.py \
    "CSV_FILE_PARSE"    : [1, 1, 1],  # csvFileParse.py \

    # for parsing data from source database
    "SRC_DB_PARSE"      : [1, 1, 1],  # srcDBParse.py \

    # for cfgLoad
    "LIB_CFG_LOAD"      : [1, 1, 1],  # cfgLoad.py \
    
    "DISTRI_QUEUE"      : [1, 1, 1],  # distriQueue.py
        
    # end for new module switches
}

class synDict:
    "Dict with mutex protection"
    def __init__(self):
        self.lock = threading.Lock()
        self.dict = {}
    
    def dictSet(self, dict):
        "set the dict for this module"
        self.lock.acquire()
        self.dict = dict
        self.lock.release()
        
    def valueSet(self, key, value):
        "insert value into dict with key"
        self.lock.acquire()
        self.dict[key] = value
        self.lock.release()    
        return 'OK'

    def valueGet(self, key):
        "get value of key from dict"
        self.lock.acquire()
        if self.dict.has_key(key):
            retVal = self.dict[key]
        else:
            retVal = None
        self.lock.release()    
        return retVal

class synFile:
    "a synchronized file object"
    def __init__(self):
        self.file = None
        self.lock = threading.Lock()

    def fileOpen(self, fileName):
        "open the file"
        self.lock.acquire()
        try:
            self.file = open(fileName, 'a')
            rlt = "OK"
        except:
            print "ERROR: synFile:fileOpen, in open()"
            rlt = "ERROR"
        self.lock.release()        
        return rlt

    def fileWrite(self, string):
        "write string to the opened file"
        self.lock.acquire()
        try:
            self.file.write(string)
            self.file.flush()
            rlt = "OK"
        except:
            print "ERROR: synFile:fileWrite, in write()"
            rlt = "ERROR"
        self.lock.release()        
        return rlt
        
    def fileClose(self):
        "open the file"
        self.lock.acquire()
        try:
            self.file.close()
            rlt = "OK"
        except:
            print "ERROR: synFile:fileClose, in close()"
            rlt = "ERROR"
        self.lock.release()        
        return rlt

# log levels
_logLevels = \
{\
    "ERROR"  :  0,\
    "WARN"   :  1,\
    "EVENT"  :  2,\
}

# global variants
_logSwitches = synDict()    # synchronized switches
_logFile = synFile()        # log file
_curTime = (0, 0, 0)
_logFileName = ''
    
def logInit(filename, logSwTbl=None, logSwitch=None):
    "initialize module log with the log file"
    # ARGs:
    #   filename    - name of log file
    #   logSwitch   - high level switch, see _logSwitch
    #   logSwTbl    - module level switch, _logSwtTbl as example
    #                 contains: application module switches
    #                           changes for library module switches
    # RETURNs: 
    #   OK, ERROR
    #
    global _logFileName, _logSwitch

    # set log file name
    _logFileName = filename

    # set logSwitch
    if logSwitch != None:
        _logSwitch.update(logSwitch)
    
    # set switches
    if logSwTbl != None:
        _logSwtTbl.update(logSwTbl)
    
    _logSwitches.dictSet(_logSwtTbl)
    
    # get localtime
    global _curTime
    _curTime = time.localtime()[0:3]
        
    # open log file
    logfile=_logFileName+('.%4d%02d%02d'%(_curTime[0],_curTime[1],_curTime[2]))
    if _logFile.fileOpen(logfile) == "ERROR":
        print "ERROR: logInit(), in _logFile.fileOpen()"
        return "ERROR"
    
    # get current time
    cTime = time.ctime(time.time())
    logStr = "System starts at " + cTime
    
    # write start up message
    if _logSwitch['stdOut']:
        print logStr
    if _logFile.fileWrite(logStr + "\n") == "ERROR":
        return "ERROR"
    
    return "OK"

def msg(mod, level, format, values=()):
    "log message"
    # ARGs:
    #   module    - name of module switch
    #   level     - 'ERROR', 'WARN', 'EVENT'
    #   format    - similar to print
    #   values    - similar to print
    #
    # RETURNs: 
    #   OK, ERROR
    #    
    # Example:
    #   log.msg('MY_MODULE', 'ERROR', "Some error happens")
    #
    if _logSwitch['all'] == 0:
        return
        
    if _logSwitch['event'] == 0 and level == 'EVENT':
        return
        
    if _logSwitch['warn'] == 0 and level == 'WARN':
        return
        
    if _logSwitch['error'] == 0 and level == 'ERROR':
        return

    try:
        # prepare for log message
        if values != ():
                logStr = format % values
        else:
            logStr = format
    
        # get localtime
        tmpTime = time.localtime()[0:3]    
        # get current time
        t = time.ctime(time.time())    
        
        global _curTime
        global _logFileName
        
        if tmpTime != _curTime:
            _curTime = tmpTime
            # close cur logfile
            if _logFile.fileClose() == "ERROR":
                print "WARN: msg(), in _logFile.fileClose()"
            # open new log file
            logfile=_logFileName+('.%4d%02d%02d'%(_curTime[0],_curTime[1],_curTime[2]))
            if _logFile.fileOpen(logfile) == "ERROR":
                print "WARN: msg(), in _logFile.fileOpen()"
            else:
                logChgStr = "Log file changed at " + t
                if _logSwitch['stdOut']:
                    print logChgStr
                _logFile.fileWrite(logChgStr + "\n")
    
        # get module switches
        lev = _logLevels[level]
        swt = _logSwitches.valueGet(mod)
        if swt == None or swt[lev] == 0:
            return
        
        # header lines
        logHdr = "-------------------\n" + t + ", [" + level + "]: "
        logStr = logHdr + logStr
    
        # write log message
        if _logSwitch['stdOut']:
            print logStr
            
        if _logFile.fileWrite(logStr + "\n") == "ERROR":
            return
    except:
        print "\nERROR: in log.msg() -- ", sys.exc_info()
        
        import traceback
        traceback.print_exc(file=sys.stdout)
        
        print "\n"
