#ifdef WIN32_VSS
#define B_VSS_VISTA
#include "vss_generic.cpp"
#endif
