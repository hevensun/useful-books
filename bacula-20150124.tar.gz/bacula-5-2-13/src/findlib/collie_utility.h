/*
   Bacula® - The Network Backup Solution

   Copyright (C) 2004-2008 Free Software Foundation Europe e.V.

   The main author of Bacula is Kern Sibbald, with contributions from
   many others, a complete list can be found in the file AUTHORS.
   This program is Free Software; you can redistribute it and/or
   modify it under the terms of version three of the GNU Affero General Public
   License as published by the Free Software Foundation and included
   in the file LICENSE.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
   02110-1301, USA.

   Bacula® is a registered trademark of Kern Sibbald.
   The licensor of Bacula is the Free Software Foundation Europe
   (FSFE), Fiduciary Program, Sumatrastrasse 25, 8006 Zürich,
   Switzerland, email:ftf@fsfeurope.org.
*/
/*
 * Properties we use for getting and setting collie tools for sheepdog.
 */

#ifndef __COLLIE_UTILITY_H
#define __COLLIE_UTILITY_H

/*
 * get the obj size from sheepdog 0.7.4
 */ 
#include <string.h>
#define __STDC_FORMAT_MACROS
#include <inttypes.h>
#include <stdint.h>
//#define SD_DATA_OBJ_SIZE (UINT64_C(1) << 22)
//const int SD_DATA_OBJ_SIZE=4*1024*1024;
const uint64_t SD_DATA_OBJ_SIZE=4*1024*1024;


#define SD_MAX_VDI_LEN 256U
#define SD_MAX_VDI_TAG_LEN 256U

#define SD_READ_CMD_LEN 4*1024U
#define SD_READ_RESULT_LEN 4*1024*1024
#define SD_READ_WAIT 60

/*get below for sheepdog 0.7.4*/
struct backup_hdr {
	uint32_t version;
	uint32_t magic;
};

struct obj_backup {
	uint32_t idx;
	uint32_t offset;
	uint32_t length;
	uint32_t reserved;
	uint8_t data[SD_DATA_OBJ_SIZE];
};
/*end get below for sheepdog 0.7.4*/
const int EMPTY_BACKFILE_SIZE = 24;

struct vdi_vol{
	char      type; /* s:snapshot; c:clone; =:vdi data*/
	char      vdi_name[SD_MAX_VDI_LEN];
	char      snap_id[SD_MAX_VDI_TAG_LEN];
	uint64_t  vdi_size;
	uint64_t  used_space;
	uint64_t  shared_space;
	uint64_t  create_time;
	uint64_t  vdi_id;
	uint64_t  copies;
	char      snap_tag[SD_MAX_VDI_TAG_LEN];
};

int       create_vdi_olist (const char *vdiname, const char* snap, char* backup_file, const char* ecolliepath);
int       write_vdi_block  (const char* vdiname, uint64_t addr, char* results, int size=SD_DATA_OBJ_SIZE);
uint64_t  get_vdi_inode    (char* results, struct vdi_vol &inode, const char * snapidtag);
uint64_t  get_vdi_size     (const char* vdiname, const char* snapidtag);
int       get_nth_obj      (const char* vdiname, const char* snapidtag, uint64_t n, char* results, uint64_t nblock=1);
int       get_nth_obj_diff (const char* vdiname, const char* last_snap,const char* new_snap, uint64_t n, char* results);
bool      exists_nth_obj   (const char* vdiname, const char* snapidtag, uint64_t n);
uint64_t  get_obj_num      (const char* vdiname, const char* snapidtag);
bool      create_snapshot  (const char* vdiname, char* snaptag);
bool      check_vdi_changes(const char *vdiname, const char* last_snap, const char* new_snap, char* backup_file);
bool      check_vdi_ochanges(const char *vdiname, const char* last_snap, const char* new_snap, char* backup_file, const char* ecolliepath);
int      create_vdi_ochanges(const char *from_vdiname, const char* from_snap, const char* to_vdiname, const char* to_snap, char* backup_file, const char* ecolliepath);
int       create_vdi(const char * vdiname, uint64_t size=1073741824);
int       delete_vdi(const char * vdiname, const char* snapidtag = "0");
bool      exist_vdi (const char * vdiname, const char* snapidtag = "0");
void      delete_obsolete_snap(const char* vdiname, const char* snapidtag);
int       rollback_vdi(const char * vdiname, const char* snapidtag );
int       resize_vdi       (const char* vdiname, uint64_t size);
#endif
