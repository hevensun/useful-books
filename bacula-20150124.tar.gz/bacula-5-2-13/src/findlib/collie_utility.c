/*
   Bacula® - The Network Backup Solution

   Copyright (C) 2004-2012 Free Software Foundation Europe e.V.

   The main author of Bacula is Kern Sibbald, with contributions from
   many others, a complete list can be found in the file AUTHORS.
   This program is Free Software; you can redistribute it and/or
   modify it under the terms of version three of the GNU Affero General Public
   License as published by the Free Software Foundation and included
   in the file LICENSE.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
   General Public License for more details.

   You should have received a copy of the GNU Affero General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
   02110-1301, USA.

   Bacula® is a registered trademark of Kern Sibbald.
   The licensor of Bacula is the Free Software Foundation Europe
   (FSFE), Fiduciary Program, Sumatrastrasse 25, 8006 Zürich,
   Switzerland, email:ftf@fsfeurope.org.
   */
/**
 * Functions to handle sheepdog for bacula.
 *
 *
 *   Original written by gang.song, December 2013
 */

#include "bacula.h"
//#include "filed.h"
#include "collie_utility.h"
#include <string.h>
#include <time.h>

int run_program_full_output_fgets(const char *program, char *result)   
{   
	FILE *ptr;   
	int ret=0;

	char *buf;
	buf = (char *)malloc(SD_DATA_OBJ_SIZE+1);
	bool first = true;

	if((ptr=popen(program, "r"))!=NULL){   
		while(fgets(buf, SD_DATA_OBJ_SIZE, ptr) != NULL){
			if(!first){
				strcat(result, buf); 
			}else{ 
				strcpy(result,buf);
				first = false;
			}
		}
		pclose(ptr);   
		ptr = NULL;   
	}   
	else{   
		Dmsg1(100, "popen error:%s\n", program);   
		ret = -1;
	}   
	free(buf);
	return ret;
} 

int run_program_full_output_fread(const char *program, char *result, uint64_t nblock=1)   
{   
	FILE *ptr;   
	int ret=0;
	if((ptr=popen(program, "r"))!=NULL){   
		size_t nbyte = fread(result, 1, SD_DATA_OBJ_SIZE * nblock, ptr);   
		if(nbyte != (size_t)SD_DATA_OBJ_SIZE * nblock){
			Dmsg2(100, "fread erorr:%s, ret:%d\n", program, nbyte);   
			ret = -1;
		}
		pclose(ptr);   
		ptr = NULL;   
	}   
	else{   
		Dmsg1(100, "popen error:%s\n", program);   
		ret = -1;
	}   
	return ret;
} 

/**
 * return 0 success
 */

int run_program_full_input_sg(const char *program, char *result, size_t size)   
{   
	FILE *ptr;   
	int ret=0;
	if((ptr=popen(program, "w"))!=NULL){   
		size_t nbyte = fwrite(result, 1, size, ptr);   
		if(nbyte != size){
			Dmsg2(100, "fwrite erorr:%s, ret:%d\n", program, nbyte);   
			ret = -1;
		}
		pclose(ptr);   
		ptr = NULL;   
	}   
	else{   
		Dmsg1(100, "popen error:%s\n", program);   
		ret = -1;
	}   
	return ret;
} 
/*
 * write vdi block data
 * return 0 success
 */
int write_vdi_block(const char* vdiname, uint64_t addr, char* results, int size)
{
	int ret=0;

	char program[SD_READ_CMD_LEN];
	snprintf(program,SD_READ_CMD_LEN,"collie vdi write %s %"PRIu64" %d", vdiname, addr, size );
	Dmsg1(100, "cmd:%s\n", program);
	ret = run_program_full_input_sg(program, results, size);
	return ret;
}

/**
 * print struct vdi_vol data
 */

void print_vdi_vol(struct vdi_vol inode)
{
	//s vdi-data 9 1073741824 0 4194304 1388022699 70e35d 1 vdi-data-s$
	printf("inode info:\n");
	printf("type    :%c\n", inode.type);
	printf("vid_name:%s\n", inode.vdi_name);
	printf("snap_id :%s\n", inode.snap_id);
	printf("vdi_size:%" PRIu64 "\n", inode.vdi_size);
	printf("snap_tag:%s\n", inode.snap_tag);
}


/**
 * get vdi-name useful info from the vdi list's output
 *
 */
uint64_t get_vdi_inode(char* results, struct vdi_vol &inode, const char * snapidtag)
{

	//Dmsg1(100, "parse output:%s\n",results);
	char *pbegin = results;

	while(*pbegin){

		memset(&inode, 0 , sizeof(inode));
		char* pos = strchr(pbegin,'\n');
		if((pos==NULL)){
			break;
		}

		*pos = '\0';

		//s vdi-data 9 1073741824 0 4194304 1388022699 70e35d 1 vdi-data-s$
		//printf("%s\n",pbegin);
		sscanf(pbegin,"%c %s %s %llu %llu %llu %llu %s %llu %s",
				&inode.type, inode.vdi_name, &inode.snap_id, &inode.vdi_size, &inode.used_space,
				&inode.shared_space, &inode.create_time, &inode.vdi_id, &inode.copies, inode.snap_tag );
		//print_vdi_vol(inode);
		//printf("got snaptag:%s, input snapid:%s\n\n", inode.snap_tag, snapidtag);
		if(strcmp(inode.snap_id,snapidtag)==0||(strcmp(inode.snap_tag,snapidtag)==0))
		{
			//printf("got it\n");
			return inode.vdi_size;
		}
		pbegin = pos+1;
	}
	return 0;
}

/**
 * get real size for the given vdiname and snapshotid( or tag name)
 */
uint64_t get_vdi_size(const char* vdiname, const char* snapidtag)
{

	//char* program = "/opt/sheepdog/sbin/collie vdi list vdi-data -r";
	//int   wait    =  SD_READ_WAIT;
	char program[SD_READ_CMD_LEN];

	snprintf(program,SD_READ_CMD_LEN,"collie vdi list %s -r",	vdiname);

	POOLMEM *results;
	uint64_t vdi_size=0;
	results = get_memory(SD_READ_RESULT_LEN);
	int   status;
	int   tries = 5;
	Dmsg1(100, "cmd:%s\n", program);
	//while ((status=run_program_full_output(program, wait, results)) != 0 ){
	while ((status=run_program_full_output_fgets(program, results)) != 0 ){
		if (tries-- > 0) {
			continue;
		}
	}
	if(status!=0){
		goto gvs_bail_out;
	}

	Dmsg2(100, "run_program:%s, ret=%d\n",program, status);

	struct vdi_vol inode;
	vdi_size= get_vdi_inode(results, inode, snapidtag);


gvs_bail_out:	
	free_pool_memory(results);
	Dmsg2(100, "vdi-name:%s, size =%"PRIu64"\n", vdiname, vdi_size);
	return vdi_size;

}
/**
 * for bacula read use
 */
int get_nth_obj(const char* vdiname, const char* snapidtag, uint64_t n, char* results, uint64_t nblock)
{
	int ret = 0;
	//char* program = "/opt/sheepdog/sbin/collie vdi read  vdi-data 0 4194304";
	//int   wait    =  SD_READ_WAIT;
	char program[SD_READ_CMD_LEN];

	//if(!exists_nth_obj(vdiname, snapidtag, n)){
	//	Dmsg3(500, "%s, %s, %d obj not exists!\n", vdiname, snapidtag, n);
	//	return ret;
	//}

	if(strcmp(snapidtag,"0")==0 ||strlen(snapidtag)==0){
		snprintf(program,SD_READ_CMD_LEN,"collie vdi read %s %"PRIu64" %"PRIu64, 
				vdiname, n*(uint64_t)SD_DATA_OBJ_SIZE, SD_DATA_OBJ_SIZE*nblock);
	}else{
		snprintf(program,SD_READ_CMD_LEN,"collie vdi read -s %s %s %"PRIu64" %"PRIu64, 
				snapidtag, vdiname, n*(uint64_t)SD_DATA_OBJ_SIZE, SD_DATA_OBJ_SIZE*nblock);
	}
    printf("%s\n", program);
	int   status;
	int   tries = 1;
	Dmsg1(500, "cmd:%s\n", program);
	while ((status=run_program_full_output_fread(program, results, nblock)) != 0 ){
		if ( --tries > 0) {
			continue;
		}
	}
	if(status!=0){
		goto r_bail_out;
	}
	ret = SD_DATA_OBJ_SIZE * nblock;


r_bail_out:	
	return ret;

}

bool exists_nth_obj(const char* vdiname, const char* snapidtag, uint64_t n)
{
	bool ret = false;
	//char* program = "/opt/sheepdog/sbin/collie vdi object -i 0 vdi-data";
	char program[SD_READ_CMD_LEN];

	if(strcmp(snapidtag,"0")==0 ||strlen(snapidtag)==0){
		snprintf(program,SD_READ_CMD_LEN,"collie vdi object -i  %"PRIu64" %s", 
				n, vdiname);
	}else{
		snprintf(program,SD_READ_CMD_LEN,"collie vdi object -i %"PRIu64" -s %s %s ", 
				n, snapidtag, vdiname);
	}
	//int   wait    =  SD_READ_WAIT;
	POOLMEM *results;
	results = get_memory(SD_READ_RESULT_LEN);
	int   status;
	int   tries = 5;
	Dmsg1(600, "cmd:%s\n", program);
	//while ((status=run_program_full_output(program, wait, results)) != 0 ){
	while ((status=run_program_full_output_fgets(program, results)) != 0 ){
		if (tries-- > 0) {
			continue;
		}
	}
	if(status!=0){
		goto eno_bail_out;
	}

	Dmsg1(600, "results:%s\n", results);

	if(strncmp(results, "Looking",7)==0)
	{
		Dmsg1(100, "%"PRIu64" obj exists\n", n);
		ret = true;
	}

eno_bail_out:	
	free_pool_memory(results);
	return ret;

}


/**
 * get obj count for the given vdiname and snapshotid( or tag name)
 */
uint64_t get_obj_num(const char* vdiname, const char* snapidtag)
{
	uint64_t vdi_size = get_vdi_size(vdiname, snapidtag);
	if(vdi_size<0)
	{
		return 0;
	}

	Dmsg2(100, "vdi_size:%"PRIu64", DATA_OBJ_SIZE:%"PRIu64"\n", vdi_size, SD_DATA_OBJ_SIZE);
	uint64_t obj_num  = vdi_size / SD_DATA_OBJ_SIZE;
	Dmsg1(100, "objs:%d\n", obj_num);
	return obj_num;
}
/**
 * create a snapshot for a given name, create tag like : vdi-name-2014-01-08-11-23-01
 * return true success
 *        false error
 */ 
bool  create_snapshot(const char* vdiname, char* snaptag)
{
	int  ret = -1;
	//int   wait    =  SD_READ_WAIT;
	char  program[SD_READ_CMD_LEN];

	char szTime[30];
	time_t lt      = time(NULL);
	struct tm *lpt = localtime(&lt);
	sprintf( szTime, "%4.4d-%2.2d-%2.2d-%2.2d-%2.2d-%2.2d",
			lpt->tm_year+1900, lpt->tm_mon+1, lpt->tm_mday, lpt->tm_hour, lpt->tm_min, lpt->tm_sec);

	sprintf(snaptag, "%s-ss-%s", vdiname, szTime);

	if(strlen(snaptag)>0){
		snprintf(program,SD_READ_CMD_LEN,"collie vdi snapshot -s %s %s", 
				snaptag, vdiname);
		/*run the shell command*/
		ret = system(program);  
	}else{
		Dmsg1(100, "error: can't create snapshot for %s\n", vdiname);
	}

	Dmsg2(600,"system[%s]return:%d\n", program, ret);
	return (ret==0);
}

/**
 * create vdi object list
 * return backup_file size
 *
 */
int create_vdi_olist(const char *vdiname, const char* snap, char* backup_file, const char* ecolliepath)
{

	int ret = -1;
	char cur_path[FILENAME_MAX];
	getcwd(cur_path, sizeof(cur_path));

	snprintf(backup_file, FILENAME_MAX, "%s/collie.olist.%d.%u",cur_path, getpid(), (unsigned int)pthread_self());

	char program[SD_READ_CMD_LEN];
	if(strlen(ecolliepath)==0){
		snprintf(program,SD_READ_CMD_LEN,"ecollie vdi olist -s %s %s > %s", snap, vdiname, backup_file);
	}
	else{
		snprintf(program,SD_READ_CMD_LEN,"%s vdi olist -s %s %s > %s", ecolliepath, snap, vdiname, backup_file);
	}

	int re = system(program);
	Dmsg2(100, "cmd:%s, ret:%d\n", program, re);
	printf("cmd:%s, ret:%d\n", program, re);
	/*backup command return 16 is OK, else error*/
	if(0 == re){
		struct stat st;
		if(0 == stat(backup_file, &st)){
			Dmsg1(100, "stat %s, ret=0\n", backup_file);
			ret = st.st_size;
		}
        else{
            Dmsg1(100, "stat backup_file:%s, error!", backup_file);
        }
	}
	else{
		Dmsg1(100, "cmd:%s, error", program);
	}

	return ret;
}

/**
 * check two snapshot same or different
 *
 */
int create_vdi_ochanges(const char *from_vdiname, const char* from_snap, const char* to_vdiname, const char* to_snap, char* backup_file, const char* ecolliepath)
{

	int ret = -1;
	char cur_path[FILENAME_MAX];
	getcwd(cur_path, sizeof(cur_path));
	snprintf(backup_file, FILENAME_MAX, "%s/collie.backfile.%d.%u",cur_path, getpid(), (unsigned int)pthread_self());

	char program[SD_READ_CMD_LEN];
	memset(program,0,sizeof(program));
	if(strlen(ecolliepath)==0){
		snprintf(program,SD_READ_CMD_LEN,"ecollie vdi odiff -S %s -N %s -s %s -n %s > %s", from_snap, from_vdiname, to_snap, to_vdiname, backup_file);
	}
	else{
		snprintf(program,SD_READ_CMD_LEN,"%s vdi odiff -S %s -N %s -s %s -n %s > %s", ecolliepath, from_snap, from_vdiname, to_snap, to_vdiname, backup_file);
	}

	int re = system(program);
	Dmsg2(100, "cmd:%s, ret:%d\n", program, re);
	if(0 == re){
		struct stat st;
		if(0 == stat(backup_file, &st)){
			Dmsg1(100, "stat %s, ret=0\n", backup_file);
			ret =  st.st_size;
		}
        else{
            Dmsg1(100, "stat backup_file:%s, error!", backup_file);
            ret = -1;
        }
	}
	else{
		Dmsg1(100, "cmd:%s, error", program);
        ret = -1;
	}

	return ret;
}
/**
 * check two snapshot same or different
 *
 */
bool check_vdi_ochanges(const char *vdiname, const char* last_snap, const char* new_snap, char* backup_file, const char* ecolliepath)
{

	bool ret = false;
	char cur_path[FILENAME_MAX];
	getcwd(cur_path, sizeof(cur_path));
	snprintf(backup_file, FILENAME_MAX, "%s/collie.backfile.%d.%u",cur_path, getpid(), (unsigned int)pthread_self());

	char program[SD_READ_CMD_LEN];
	memset(program,0,sizeof(program));
	if(strlen(ecolliepath)==0){
		snprintf(program,SD_READ_CMD_LEN,"ecollie vdi obackup -F %s -s %s %s > %s", last_snap, new_snap, vdiname, backup_file);
	}
	else{
		snprintf(program,SD_READ_CMD_LEN,"%s vdi obackup -F %s -s %s %s > %s", ecolliepath, last_snap, new_snap, vdiname, backup_file);
	}

	int re = system(program);
	Dmsg2(100, "cmd:%s, ret:%d\n", program, re);
	/*backup command return 16 is OK, else error*/
	if(0 == re){
		struct stat st;
		if(0 == stat(backup_file, &st)){
			Dmsg1(100, "stat %s, ret=0\n", backup_file);
			if( 0 != st.st_size){
				ret = true;
			}
		}
        else{
            Dmsg1(100, "stat backup_file:%s, error!", backup_file);
        }
	}
	else{
		Dmsg1(100, "cmd:%s, error", program);
	}

	return ret;
}
/**
 * check two snapshot same or different
 *
 */
bool check_vdi_changes(const char *vdiname, const char* last_snap, const char* new_snap, char* backup_file)
{

	bool ret = false;
	char cur_path[FILENAME_MAX];
	getcwd(cur_path, sizeof(cur_path));
	snprintf(backup_file, FILENAME_MAX, "%s/collie.backfile.%d.%u",cur_path, getpid(), (unsigned int)pthread_self());

	char program[SD_READ_CMD_LEN];
	memset(program,0,sizeof(program));
	snprintf(program,SD_READ_CMD_LEN,"collie vdi backup -F %s -s %s %s > %s", last_snap, new_snap, vdiname, backup_file);

	int re = system(program);
	Dmsg2(100, "cmd:%s, ret:%d\n", program, re);
	/*backup command return 16 is OK, else error*/
	if(4096 == re){
		struct stat st;
		if(0 == stat(backup_file, &st)){
			if(EMPTY_BACKFILE_SIZE != st.st_size){
				return true;
			}
			else{
				Dmsg2(100, "stat %s size != %d", backup_file, EMPTY_BACKFILE_SIZE);
			}
		}
		else{
			Dmsg1(100, "stat %s error", backup_file);
		}
	}
	else{
		Dmsg1(100, "cmd:%s, error", program);
	}

	return ret;
}
/**
 * get different obj for nth according two snapshots
 * return 0     same
 *        size  different
 */
int  get_nth_obj_diff(const char* vdiname, const char* last_snap,const char* new_snap, uint64_t n, char* results)
{
	int ret = 0;
	POOLMEM *last_obj_data = get_memory(SD_DATA_OBJ_SIZE);
	POOLMEM *new_obj_data  = get_memory(SD_DATA_OBJ_SIZE);
	int  last_obj_size;
	int  new_obj_size;

	last_obj_size = get_nth_obj(vdiname, last_snap, n, last_obj_data);
	new_obj_size  = get_nth_obj(vdiname, new_snap,  n, new_obj_data);

	if((last_obj_size ==0) && (new_obj_size == 0) ){
		goto good_gnod;
	}

	if((last_obj_size !=0) && (new_obj_size == 0) ){
		memset(results, SD_DATA_OBJ_SIZE, 0);
		ret = SD_DATA_OBJ_SIZE;
		goto good_gnod;
	}

	if(((last_obj_size ==0)&&(new_obj_size != 0))
			||(memcmp(last_obj_data, new_obj_data, SD_DATA_OBJ_SIZE)!=0)){
		ret = new_obj_size;
		memcpy(results, new_obj_data, new_obj_size);
		goto good_gnod;
	}

good_gnod:
	free_pool_memory(last_obj_data);
	free_pool_memory(new_obj_data);

	return ret;

}
/**
 * create a vdi file 
 * <0 error
 */
int create_vdi(const char * vdiname, uint64_t size)
{
	int ret = -1;
	char program[SD_READ_CMD_LEN]={0};

	memset(program,0,sizeof(program));
	snprintf(program,SD_READ_CMD_LEN,"collie vdi create %s %"PRIu64"K", 
			vdiname, (uint64_t)size/1024);

	Dmsg1(600, "cmd:%s\n", program);
	ret = system(program);  

	return ret;

}
/*
 * <0 erro
 */
int resize_vdi(const char* vdiname, uint64_t size)
{
    int ret = -1;
	char program[SD_READ_CMD_LEN]={0};

	memset(program,0,sizeof(program));
	snprintf(program,SD_READ_CMD_LEN,"collie vdi resize %s %"PRIu64, 
			vdiname, size);

	Dmsg1(600, "cmd:%s\n", program);
	ret = system(program);  

	return ret;
}

/**
 * delete vdi
 * <0 error
 */
int delete_vdi(const char * vdiname, const char* snapidtag )
{
	int ret = -1;
	char program[SD_READ_CMD_LEN]={0};
	memset(program,0,sizeof(program));

	if(strcmp(snapidtag, "0")==0){
		snprintf(program,SD_READ_CMD_LEN,"collie vdi delete %s", vdiname );
	}
	else{
		snprintf(program,SD_READ_CMD_LEN,"collie vdi delete -s %s %s", snapidtag, vdiname );
	}

	Dmsg1(600, "cmd:%s\n", program);
	ret = system(program);  

	return ret;
}

/**
 * rollback vdi
 * <0 error
 */
int rollback_vdi(const char * vdiname, const char* snapidtag )
{
	int ret = -1;
	char program[SD_READ_CMD_LEN]={0};
	memset(program,0,sizeof(program));

	snprintf(program,SD_READ_CMD_LEN,"echo yes|collie vdi rollback -s %s %s", snapidtag, vdiname );

	Dmsg1(600, "cmd:%s\n", program);
	ret = system(program);  

	return ret;
}

/**
 * exist
 * 
 */
bool exist_vdi(const char * vdiname, const char* snapidtag )
{
	if(get_vdi_size(vdiname, snapidtag)==0){
		return false;
	}
	else{
		return true;
	}
}

/**
 * delete not used snapshot, first snapshot must contain "-ss-", 
 * not equal input snapidtag will be deleted
 */
void delete_obsolete_snap(const char* vdiname, const char* snapidtag)
{

	char program[SD_READ_CMD_LEN];
	snprintf(program,SD_READ_CMD_LEN,"collie vdi list %s -r",	vdiname);

	POOLMEM *results;
	results = get_memory(SD_READ_RESULT_LEN);
	int   status;
	int   tries = 5;
	char *pbegin = results ;
	struct vdi_vol inode;
	Dmsg1(100, "cmd:%s\n", program);
	//while ((status=run_program_full_output(program, wait, results)) != 0 ){
	while ((status=run_program_full_output_fgets(program, results)) != 0 ){
		if (tries-- > 0) {
			continue;
		}
	}
	if(status!=0){
		goto dos_bail_out;
	}
	Dmsg2(100, "run_program:%s, ret=%d\n",program, status);

    // next to delete snap
	while(*pbegin){

		memset(&inode, 0 , sizeof(inode));
		char* pos = strchr(pbegin,'\n');
		if((pos==NULL)){
			break;
		}

		*pos = '\0';

		//s vdi-data 9 1073741824 0 4194304 1388022699 70e35d 1 vdi-data-s$
		//printf("%s\n",pbegin);
		sscanf(pbegin,"%c %s %s %llu %llu %llu %llu %s %llu %s",
				&inode.type, inode.vdi_name, &inode.snap_id, &inode.vdi_size, &inode.used_space,
				&inode.shared_space, &inode.create_time, &inode.vdi_id, &inode.copies, inode.snap_tag );
		//print_vdi_vol(inode);
		//printf("got snaptag:%s, input snapid:%s\n\n", inode.snap_tag, snapidtag);
		if((strstr(inode.snap_tag, "-ss-")!=NULL)&&(strcmp(inode.snap_tag,snapidtag)!=0))
		{
			printf("%s:will be deleted\n", inode.snap_tag);
			Dmsg1(100, "%s:will be deleted\n", inode.snap_tag);
            delete_vdi(vdiname, inode.snap_tag);
		}
		pbegin = pos+1;
	}

dos_bail_out:	
	free_pool_memory(results);
}

#ifdef TEST_COLLIE

int main()
{
	init_stack_dump();
	lmgr_init_thread(); /* initialize the lockmanager stack */
	init_msg(NULL, NULL);

    rollback_vdi("vdi-test", "s1");
    return 0;

    delete_obsolete_snap("volume-be58b739-3f3f-4f5c-91b1-b733c6854fa2", "volume-be58b739-3f3f-4f5c-91b1-b733c6854fa2-ss-2014-03-25-14-07-27");

    return 0;
	//printf("max int %d\n", INT_MAX);
	//
	//
	POOLMEM *results;
	results = get_memory(SD_DATA_OBJ_SIZE*4);
	FILE* fp;
	fp = fopen("/root/Man.mkv", "rb");
	uint64_t total = 0;
	while(!feof(fp)){
		size_t size_n = fread(results, 1, 4194304*4, fp);
		write_vdi_block("vdi-data", total , results, size_n);
		total += size_n;
		printf("total:%"PRIu64", read:%zu\n", total, size_n);
	}


	return 0;

	printf("%d\n", exist_vdi("vdi-data", "s"));
	printf("%d\n", exist_vdi("vdi-data", "vdi-data-ss-2014-02-13-17-28-41"));
	return 0;
	bool ret; 
	char tag[SD_DATA_OBJ_SIZE];
	ret = check_vdi_ochanges("vdi-data", "vdi-data-tt-2", "vdi-data-tt-2",tag, "");
	printf("%d %s\n", ret, tag);
	ret = check_vdi_ochanges("vdi-data", "vdi-data-tt-1", "vdi-data-tt-2",tag, "");
	printf("%d %s\n", ret, tag);
	return 0;

	int idx;
	//FILE *fp = fopen("t","r");
	while(fscanf(fp,"%d", &idx)==1){
		printf("%d ", idx);
	}

	return 0;

	//int ret;
	ret = create_vdi_olist("vdi-data", "vdi-data-tt-1", tag, "" );
	printf("ret:%d, %s\n", ret, tag);
	ret = create_vdi_olist("vdi-data", "vdi-data-ttt-2", tag, "" );
	printf("ret:%d, %s\n", ret, tag);
	return 0;
	//POOLMEM *results;
	results = get_memory(SD_DATA_OBJ_SIZE);
	get_nth_obj("vol-vdi-1401261621300", "vol-vdi-1401261621300-s1", 1000, results);
	return 0;
	//
	ret = exist_vdi ("vdi-tst", "0");
	printf("exist:%d", ret);
	delete_vdi("vdi-tst", "0");

	return 0;

	uint64_t size;
	size = get_obj_num("vdi-mkv", "vdi-mkv-ss-2014-01-23-15-26-02");
	for(uint64_t i=0;i<size;i++)
	{
		printf("read block %"PRIu64"\n", i);
		get_nth_obj("vdi-mkv", "vdi-mkv-ss-2014-01-23-15-26-02", i, results);
	}
	printf("size:%"PRIu64"\n", size);
	return 0;


	ret = create_snapshot("vdi-data", tag);
	printf("%d %s\n", ret, tag);
	return 0 ;
	results = get_memory(SD_DATA_OBJ_SIZE);

	run_program_full_output_fgets("collie vdi list -r vdi-data", results);

	printf("%s\n", results);

	return 0;

	char program[SD_READ_CMD_LEN];

	/*
	   for(int i =0 ;i<255;i++){
	//snprintf(program,SD_READ_CMD_LEN,"collie vdi object -i %d -s vdi-data-ss-2014-01-20-13-40-13 vdi-data", i);
	//run_program_full_output(program, 60, results);
	//run_program_full_output(program, 60, results);
	ret = get_nth_obj("vdi-data", "vdi-data-ss-2014-01-20-13-40-13", i, results);
	printf("%d %d\n", i, ret);
	}
	*/
	//int num = get_obj_num("vdi-data", "0");
	//printf("get objs : %d\n", num );

	//exists_nth_obj("vdi-data","0",0);
	//get_nth_obj("vdi-data", "", 0);
	//char snap[100];
	//create_snapshot("vdi-data", snap);
	//printf("%s,%d\n", snap, strlen(snap));
	//int ret = get_nth_obj("vdi-data", "vdi-data-ss-2014-01-10", 0, results);
	//int ret = get_nth_obj_diff("vdi-data", "vdi-data-ss-2014-01-08-17-09-19", "vdi-data-ss-2014-01-10",0 , results);
	//printf("%d\n", ret);
	//printf("%s\n", results);
	//printf("%c\n", results[SD_DATA_OBJ_SIZE-1]);
	//run_program_full_output_fread("collie vdi list", results);
	//run_program_full_output_fread("collie vdi read vdi-data 0 4194304", results);
	//printf("%s", results);
	//ret = create_vdi("vdi-tmp-1234567-011", 4194304);
	//printf("%d\n", ret);
	return 0;
}
#endif
