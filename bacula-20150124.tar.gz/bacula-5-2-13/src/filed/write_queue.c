#include "write_queue.h"
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "bacula.h"
#include "filed.h"


pthread_mutex_t mutex_wq = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  cond_not_empty = PTHREAD_COND_INITIALIZER;
pthread_cond_t  cond_not_full  = PTHREAD_COND_INITIALIZER;

queue<WRITE_NODE*> write_queue;

void en_write_queue(const char* vdi_name, char* data_buf, uint64_t data_len, uint64_t start_addr, bool end_flag, sem_t* sem)
{

	//if(write_queue.size()>=100){
	//	pthread_cond_wait(&cond_not_full, &mutex_wq);
	//}

	WRITE_NODE* pTmp = (WRITE_NODE*)malloc(sizeof(WRITE_NODE));
	memset(pTmp, 0, sizeof(WRITE_NODE));

	if(!end_flag){
		strcpy(pTmp->vdi_name, vdi_name);
		pTmp->data_buf = (char*)malloc(data_len);
		memcpy(pTmp->data_buf, data_buf, data_len);
		pTmp->start_addr = start_addr;
	}
	pTmp->data_len   = data_len;
	pTmp->end_flag   = end_flag;
	pTmp->sem        = sem;
	pthread_mutex_lock(&mutex_wq);
	write_queue.push(pTmp);
	pthread_mutex_unlock(&mutex_wq);
	Dmsg1(1000, "write_queue size %lu \n", write_queue.size());

	while(write_queue.size()>100){
		sleep(1);
	}
};

void *write_worker_process(void*)
{
	WRITE_NODE* pNode=NULL;
	Dmsg1(100, "write_worker %lu start", pthread_self());
	while(true){
		//continue;
		pNode = NULL;

		pthread_mutex_lock(&mutex_wq);
		if(!write_queue.empty()){
			pNode = write_queue.front();
			write_queue.pop();
		}
		
		//if(write_queue.size()<100){
		//	pthread_cond_broadcast(&cond_not_full);
		//}
		
		pthread_mutex_unlock(&mutex_wq);


		if(pNode == NULL)
		{
			//Dmsg1(1000, "get null %lu sleep\n", pthread_self());
			sleep(5);
			continue;
		}

		if((!pNode->end_flag)&&(pNode->data_len != 0)){
			//write data
			write_vdi_block(pNode->vdi_name, pNode->start_addr, pNode->data_buf, pNode->data_len);			
			//free memory
			if(pNode->data_buf){
				free(pNode->data_buf);
			}
			if(pNode){
				free(pNode);
				pNode = NULL;
			}
		}
		else{
			if(pNode->end_flag){
				//post semaphore
				sem_post(pNode->sem);
				Dmsg1(1000, "post pNode->sem %x\n", pNode->sem);
				if(pNode){
					free(pNode);
				}
			}
			else{
				sleep(1);
			}
		}
	}
    return NULL;
}
