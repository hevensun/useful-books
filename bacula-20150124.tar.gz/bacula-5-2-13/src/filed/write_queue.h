#ifndef _WRITE_QUEUE
#define _WRITE_QUEUE

#include <queue>
#include <inttypes.h>
#include <stdio.h>
#include <semaphore.h>

using namespace std;

typedef struct _write_node
{
	char     vdi_name[FILENAME_MAX];
	char*    data_buf;
	uint64_t data_len;
	uint64_t start_addr;
	bool     end_flag;
	sem_t*   sem;
}WRITE_NODE;

typedef struct _queue_sem
{
	sem_t* sem;
	int    index;
	pthread_mutex_t  mutex;
}QUEUE_SEM;

void en_write_queue(const char* vdi_name, char* data_buf, uint64_t data_len, uint64_t start_addr, bool end_flag=false, sem_t* sem=NULL);
void *write_worker_process(void*);

#endif
