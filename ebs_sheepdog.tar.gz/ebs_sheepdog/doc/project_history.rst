Project History
===============

Sheepdog project has been founded by MORITA Kazutaka on 2010
<fix:>